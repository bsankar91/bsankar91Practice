import { useState } from "react";

function BasicHook() {
  const [username, setName] = useState("");
  const [userpassword, setPassword] = useState("");

  return (
    <div>
      <form>
        <input
          type="text"
          value={username}
          onChange={(e) => setName(e.target.value)}
          placeholder="Input Your User Name"
        />
        <p>{username}</p>
        <input
          type="text"
          value={userpassword}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Input Your User Password"
        />
        <p>{userpassword}</p>
      </form>
    </div>
  );
}

export default BasicHook;