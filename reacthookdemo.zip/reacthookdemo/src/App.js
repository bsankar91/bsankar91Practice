import logo from './logo.svg';
import './App.css';
//import BasicMatCompo from "./components/BasicMatCompo";
import User from "./components/User";
import BasicHook from "./components/BasicHook";

function App() {
  return (
    <div className="App">      
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <BasicHook></BasicHook>
        <User></User>
        <p>      
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}
export default App;
