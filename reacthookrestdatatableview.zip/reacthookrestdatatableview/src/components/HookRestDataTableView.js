import { useEffect, useState } from "react";

function HookRestDataTableView() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(false)
  useEffect(() => {
    setLoading(true)
    fetch("https://jsonplaceholder.typicode.com/users")
      .then(response => response.json())
      .then(json => setUsers(json))
      .finally(() => {
        setLoading(false)
      })
  }, [])

  return (
    <div className="HookRestDataTableView">
      {loading ? (
        <div>Loading...</div>
      ) : (
        <>
          <h1 align='center'>Users Information</h1>
          <table border={1}>
            <tr>
              <th>Name</th>
              <th>User Name</th>
              <th>Email</th>
              <th>City</th>
              <th>Phone</th>
              <th>Company Name</th>
            </tr>
            {users.map(user => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.username}</td>
                <td>{user.email}</td>
                <td>{user.address.city}</td>
                <td>{user.phone}</td>
                <td>{user.company.name}</td>
              </tr>
            ))}
          </table>
        </>
      )}
    </div>
  )
}

export default HookRestDataTableView;