import UseFetchedData from "./UseFetchedData";
 
function Users() {
    const { data } = UseFetchedData("https://api.github.com/users");

  return (
      <div>
          {data && (
            data.map((user) =>(
                <div key={user.id}>
                    <h1> {user.login} </h1>
                    <p> { user.type } </p>
                    <span onclick="this.parentElement.style.display='none'">{ user.followers_url }</span>
                </div>
            ))
          )}
      </div>
  )
}

export default Users;